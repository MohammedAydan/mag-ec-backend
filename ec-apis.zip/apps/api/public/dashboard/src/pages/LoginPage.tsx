import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button, Card, Input } from '@heroui/react';
import { AlertCircle, Eye, EyeOff, Store } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { ApiRequestError } from '@/lib/http';

const schema = z.object({
  email: z.string().email('Enter a valid email address'),
  password: z.string().min(1, 'Password is required'),
});

type FormValues = z.infer<typeof schema>;

export function LoginPage() {
  const { login, isAuthenticated, isLoading } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  if (!isLoading && isAuthenticated) return <Navigate to="/home" replace />;

  const onSubmit = async (values: FormValues) => {
    setServerError(null);
    try {
      await login(values.email, values.password);
    } catch (error) {
      if (error instanceof ApiRequestError) {
        setServerError(error.message);
      } else if (error instanceof Error) {
        setServerError(error.message);
      } else {
        setServerError('Unable to connect. Please try again.');
      }
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-10">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(198,145,73,0.18),transparent_28rem),radial-gradient(circle_at_bottom_right,rgba(79,101,120,0.16),transparent_24rem)]" aria-hidden />
      <div className="grid w-full max-w-6xl gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="hidden rounded-[2.6rem] border border-white/50 bg-[linear-gradient(145deg,rgba(30,24,20,0.92),rgba(73,55,34,0.82))] p-10 text-white shadow-[0_40px_120px_rgba(33,24,14,0.25)] lg:flex lg:flex-col lg:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/58">Embedded admin workspace</p>
            <h1 className="display-face mt-5 text-6xl leading-none tracking-[-0.05em]">Atelier Commerce</h1>
            <p className="mt-6 max-w-xl text-base leading-8 text-white/72">
              A disciplined operations desk for catalog control, order recovery, inventory movement, payments, reporting, and system stewardship.
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {[
              ['Unified command surface', 'Orders, catalog, finance, and service workflows in one deployment.'],
              ['API-first administration', 'Every action stays bound to authenticated `/api/v1` workflows and audit controls.'],
              ['Operational visibility', 'Health, queue readiness, payment motion, and customer impact surfaced together.'],
              ['Editorial visual system', 'Warm material tones, dense data rhythm, and high-signal interaction design.'],
            ].map(([title, copy]) => (
              <div key={title} className="rounded-[1.5rem] border border-white/12 bg-white/6 p-5">
                <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-white/72">{title}</h2>
                <p className="mt-3 text-sm leading-6 text-white/66">{copy}</p>
              </div>
            ))}
          </div>
        </section>

        <Card className="glass-card rounded-[2.4rem] border border-white/60 px-2 py-2 shadow-[0_34px_120px_rgba(52,37,18,0.16)]">
          <Card.Content className="px-5 py-6 md:px-8 md:py-8">
            <div className="mb-8 flex items-center gap-4">
              <div className="rounded-[1.6rem] border border-black/6 bg-white/75 p-4 text-foreground/85 shadow-sm">
                <Store size={28} />
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.26em] text-foreground/46">Commerce Command Studio</p>
                <h1 className="display-face mt-2 text-4xl font-semibold tracking-[-0.05em] text-foreground">Sign in</h1>
              </div>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
              {serverError ? (
                <div className="flex items-start gap-3 rounded-[1.4rem] border border-danger/20 bg-danger/8 px-4 py-4 text-sm text-danger" role="alert">
                  <AlertCircle size={16} aria-hidden />
                  {serverError}
                </div>
              ) : null}

              <div className="space-y-2">
                <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/48">Email address</label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  {...register('email')}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  aria-invalid={!!errors.email}
                />
                {errors.email ? (
                  <span id="email-error" className="text-sm text-danger" role="alert">
                    {errors.email.message}
                  </span>
                ) : null}
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/48">Password</label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    {...register('password')}
                    aria-describedby={errors.password ? 'password-error' : undefined}
                    aria-invalid={!!errors.password}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-foreground/45 transition hover:text-foreground"
                    onClick={() => setShowPassword((value) => !value)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {errors.password ? (
                  <span id="password-error" className="text-sm text-danger" role="alert">
                    {errors.password.message}
                  </span>
                ) : null}
              </div>

              <Button
                type="submit"
                variant="primary"
                className="mt-3 w-full font-semibold"
                isDisabled={isSubmitting}
                aria-busy={isSubmitting}
              >
                {isSubmitting ? 'Signing in…' : 'Sign in'}
              </Button>
            </form>

            <div className="mt-8 rounded-[1.4rem] border border-black/6 bg-white/55 px-4 py-4 text-sm leading-6 text-foreground/62">
              Administrator access only. Authentication and session refresh stay bound to the existing `/api/v1/auth/*` backend flow.
            </div>
          </Card.Content>
        </Card>
      </div>
    </div>
  );
}
