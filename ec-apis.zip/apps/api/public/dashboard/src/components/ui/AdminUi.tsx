/* eslint-disable react-refresh/only-export-components */
import { useEffect, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { AlertCircle, CheckCircle2, LoaderCircle, X } from 'lucide-react';
import { Button, Card, Checkbox, Chip, Input, TextArea } from '@heroui/react';
import { statusTone } from '@/lib/format';

export interface JsonAction {
  title: string;
  description: string;
  path: string;
  method: string;
  payload: unknown;
}

interface PanelProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function Panel({ title, subtitle, actions, children, className = '' }: PanelProps) {
  return (
    <Card className={`glass-card rounded-[2rem] border border-white/55 shadow-[0_28px_80px_rgba(61,42,18,0.12)] ${className}`}>
      <Card.Header className="flex flex-col gap-4 border-b border-black/6 px-6 py-5 md:flex-row md:items-start md:justify-between">
        <div className="space-y-1.5">
          <Card.Title className="text-lg font-semibold tracking-[-0.02em] text-foreground">
            {title}
          </Card.Title>
          {subtitle ? (
            <Card.Description className="max-w-2xl text-sm leading-6 text-foreground/65">
              {subtitle}
            </Card.Description>
          ) : null}
        </div>
        {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
      </Card.Header>
      <Card.Content className="px-0 py-0">{children}</Card.Content>
    </Card>
  );
}

export function Badge({ value }: { value: unknown }) {
  const text = String(value ?? 'Unknown');
  const tone = statusTone(value);
  const color =
    tone === 'success' ? 'success' :
    tone === 'warning' ? 'warning' :
    tone === 'danger' ? 'danger' :
    'default';

  return (
    <Chip
      color={color}
      variant="soft"
      size="sm"
      className="border border-black/5 px-1.5 capitalize tracking-[0.08em]"
    >
      {text}
    </Chip>
  );
}

interface TableProps {
  headers: string[];
  children: ReactNode;
  empty?: boolean;
  emptyText?: string;
}

export function DataTable({ headers, children, empty = false, emptyText = 'No records available.' }: TableProps) {
  if (empty) return <EmptyState title={emptyText} />;
  return (
    <div className="table-surface overflow-x-auto px-2 pb-3 md:px-4">
      <table className="min-w-full">
        <thead>
          <tr>{headers.map((header) => <th key={header}>{header}</th>)}</tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="px-6 py-10 text-center">
      <div className="mx-auto max-w-md rounded-[1.5rem] border border-dashed border-black/10 bg-white/45 px-6 py-8">
        <strong className="block text-sm font-semibold uppercase tracking-[0.18em] text-foreground/60">
          {title}
        </strong>
        {description ? (
          <span className="mt-3 block text-sm leading-6 text-foreground/62">{description}</span>
        ) : null}
      </div>
    </div>
  );
}

export function PageLoading() {
  return (
    <div className="flex min-h-52 flex-col items-center justify-center gap-4 px-6 py-10 text-center" aria-label="Loading dashboard data">
      <div className="rounded-full border border-black/6 bg-white/75 p-4 shadow-sm">
        <LoaderCircle className="animate-spin text-foreground/70" size={20} />
      </div>
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-foreground/55">Syncing workspace</p>
        <p className="mt-2 text-sm text-foreground/62">Loading operational data and active workflows.</p>
      </div>
    </div>
  );
}

export function LoadError({ error }: { error: unknown }) {
  return (
    <div className="mx-6 my-6 flex items-start gap-3 rounded-[1.4rem] border border-danger/20 bg-danger/8 px-4 py-4 text-danger" role="alert">
      <AlertCircle size={18} />
      <span className="text-sm leading-6">{error instanceof Error ? error.message : 'Unable to load this view.'}</span>
    </div>
  );
}

export function Feedback({ message, tone = 'success' }: { message?: string | null; tone?: 'success' | 'danger' }) {
  if (!message) return null;
  return (
    <div
      className={`mb-5 flex items-start gap-3 rounded-[1.4rem] border px-4 py-4 text-sm leading-6 ${
        tone === 'success'
          ? 'border-success/20 bg-success/8 text-success'
          : 'border-danger/20 bg-danger/8 text-danger'
      }`}
      role="status"
    >
      {tone === 'success' ? <CheckCircle2 size={17} /> : <AlertCircle size={17} />}
      <span>{message}</span>
    </div>
  );
}

export function RowActions({ children }: { children: ReactNode }) {
  return <div className="flex flex-wrap justify-end gap-2">{children}</div>;
}

export function ActionButton({
  children,
  onClick,
  tone = 'secondary',
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
}) {
  const buttonColor =
    tone === 'primary' ? 'primary' :
    tone === 'danger' ? 'danger' :
    'secondary';

  return (
    <Button
      variant={buttonColor}
      size="sm"
      onPress={onClick}
      isDisabled={disabled}
      className="font-semibold"
    >
      {children}
    </Button>
  );
}

export function StatList({ children }: { children: ReactNode }) {
  return <dl className="space-y-3 px-6 py-5">{children}</dl>;
}

export function StatRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-2 border-b border-black/6 pb-3 last:border-b-0 last:pb-0 md:flex-row md:items-center md:justify-between">
      <dt className="text-sm font-medium text-foreground/62">{label}</dt>
      <dd className="text-sm font-semibold text-foreground">{children}</dd>
    </div>
  );
}

export function Tabs({
  items,
  value,
  onChange,
}: {
  items: Array<{ key: string; label: string }>;
  value: string;
  onChange: (key: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2 px-1" role="tablist">
      {items.map((item) => (
        <Button
          key={item.key}
          variant={item.key === value ? 'primary' : 'secondary'}
          size="sm"
          onPress={() => onChange(item.key)}
          className="font-semibold"
        >
          {item.label}
        </Button>
      ))}
    </div>
  );
}

interface DialogProps {
  action: JsonAction | null;
  busy: boolean;
  error?: string | null;
  onClose: () => void;
  onSubmit: (payload: unknown) => Promise<void>;
}

function isSimpleArray(val: unknown): boolean {
  if (!Array.isArray(val)) return false;
  return val.every((item) => typeof item === 'string' || typeof item === 'number');
}

function formatKeyLabel(key: string): string {
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/[_-]/g, ' ')
    .replace(/^./, (str) => str.toUpperCase())
    .trim();
}

export function JsonActionDialog({ action, busy, error, onClose, onSubmit }: DialogProps) {
  const [prevAction, setPrevAction] = useState<JsonAction | null>(null);
  const [formState, setFormState] = useState<Record<string, unknown>>({});
  const [jsonDrafts, setJsonDrafts] = useState<Record<string, string>>({});
  const [validation, setValidation] = useState<string | null>(null);

  useEffect(() => {
    if (action === prevAction) return;
    setPrevAction(action);
    setFormState((action?.payload as Record<string, unknown>) || {});
    const drafts: Record<string, string> = {};
    if (action?.payload) {
      const payload = action.payload as Record<string, unknown>;
      Object.entries(payload).forEach(([key, val]) => {
        if (val && typeof val === 'object' && !isSimpleArray(val)) {
          drafts[key] = JSON.stringify(val, null, 2);
        }
      });
    }
    setJsonDrafts(drafts);
    setValidation(null);
  }, [action, prevAction]);

  if (!action) return null;

  const payload = (action.payload as Record<string, unknown>) || {};

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setValidation(null);

    let parseErrorKey: string | null = null;
    const finalPayload = { ...formState };

    for (const key of Object.keys(jsonDrafts)) {
      try {
        finalPayload[key] = JSON.parse(jsonDrafts[key]);
      } catch {
        parseErrorKey = key;
        break;
      }
    }

    if (parseErrorKey) {
      setValidation(`Field "${formatKeyLabel(parseErrorKey)}" must be valid JSON.`);
      return;
    }

    try {
      await onSubmit(finalPayload);
    } catch (submitError) {
      const msg = submitError instanceof Error ? submitError.message : 'Action execution failed.';
      setValidation(msg);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/35 p-4 backdrop-blur-sm"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget && !busy) onClose();
      }}
    >
      <section
        className="w-full max-w-3xl rounded-[2rem] border border-white/65 bg-[color:color-mix(in_oklab,var(--background)_90%,transparent)] shadow-[0_40px_120px_rgba(42,28,15,0.32)]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
      >
        <header className="flex items-start justify-between gap-4 border-b border-black/6 px-6 py-5">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.22em] text-foreground/45">Validated API action</span>
            <h2 id="dialog-title" className="mt-3 text-2xl font-semibold tracking-[-0.03em] text-foreground">{action.title}</h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-foreground/62">{action.description}</p>
          </div>
          <button
            className="rounded-full border border-black/8 bg-white/70 p-2 text-foreground/65 transition hover:bg-white"
            type="button"
            aria-label="Close dialog"
            onClick={onClose}
            disabled={busy}
          >
            <X size={18} />
          </button>
        </header>
        <form onSubmit={(event) => void submit(event)} className="px-6 py-6">
          <div className="grid gap-4 md:grid-cols-2">
            {Object.keys(payload).map((key) => {
              const val = payload[key];
              const label = formatKeyLabel(key);

              if (typeof val === 'boolean') {
                return (
                  <div key={key} className="md:col-span-2">
                    <label className="flex rounded-[1.4rem] border border-black/8 bg-white/55 px-4 py-4">
                      <Checkbox
                        isSelected={(formState[key] as boolean) ?? false}
                        isDisabled={busy}
                        onChange={(isSelected) => setFormState((prev) => ({ ...prev, [key]: isSelected }))}
                      >
                        <span className="ml-2 text-sm font-medium text-foreground">{label}</span>
                      </Checkbox>
                    </label>
                  </div>
                );
              }

              if (typeof val === 'number') {
                return (
                  <label key={key} className="space-y-2">
                    <span className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/48">{label}</span>
                    <input
                      type="number"
                      className="h-12 w-full rounded-[1rem] border border-black/10 bg-white/70 px-4 text-sm outline-none ring-0 transition focus:border-secondary"
                      value={(formState[key] as number) ?? ''}
                      disabled={busy}
                      required
                      onChange={(e) => setFormState((prev) => ({ ...prev, [key]: e.target.value === '' ? '' : Number(e.target.value) }))}
                    />
                  </label>
                );
              }

              if (Array.isArray(val) && isSimpleArray(val)) {
                const displayVal = Array.isArray(formState[key])
                  ? (formState[key] as unknown[]).join(', ')
                  : String(formState[key] ?? '');
                return (
                  <label key={key} className="space-y-2 md:col-span-2">
                    <span className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/48">{label} (comma separated)</span>
                    <TextArea
                      value={displayVal}
                      disabled={busy}
                      rows={3}
                      className="w-full"
                      onChange={(e: ChangeEvent<HTMLTextAreaElement>) =>
                        setFormState((prev) => ({
                          ...prev,
                          [key]: e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean),
                        }))
                      }
                    />
                  </label>
                );
              }

              if (val && typeof val === 'object') {
                return (
                  <label key={key} className="space-y-2 md:col-span-2">
                    <span className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/48">{label} (JSON)</span>
                    <TextArea
                      value={jsonDrafts[key] ?? ''}
                      disabled={busy}
                      rows={6}
                      spellCheck={false}
                      className="w-full font-mono text-sm"
                      onChange={(e: ChangeEvent<HTMLTextAreaElement>) => {
                        const raw = e.target.value;
                        setJsonDrafts((prev) => ({ ...prev, [key]: raw }));
                        try {
                          const parsed = JSON.parse(raw);
                          setFormState((prev) => ({ ...prev, [key]: parsed }));
                        } catch {
                          // Invalid JSON, caught on submit.
                        }
                      }}
                    />
                  </label>
                );
              }

              return (
                <label key={key} className="space-y-2">
                  <span className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/48">{label}</span>
                  <Input
                    value={String(formState[key] ?? '')}
                    disabled={busy}
                    required
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setFormState((prev) => ({ ...prev, [key]: e.target.value }))}
                  />
                </label>
              );
            })}
          </div>
          {(validation || error) ? (
            <div className="mt-5 flex items-start gap-3 rounded-[1.2rem] border border-danger/20 bg-danger/8 px-4 py-3 text-sm text-danger">
              <AlertCircle size={17} />
              <span>{validation || error}</span>
            </div>
          ) : null}
          <footer className="mt-6 flex flex-wrap justify-end gap-3">
            <Button variant="secondary" type="button" onPress={onClose} isDisabled={busy}>
              Cancel
            </Button>
            <Button variant="primary" type="submit" isDisabled={busy}>
              {busy ? 'Executing…' : 'Execute action'}
            </Button>
          </footer>
        </form>
      </section>
    </div>
  );
}

export const layout = {
  grid2: 'grid gap-5 lg:grid-cols-2',
  grid4: 'grid gap-4 md:grid-cols-2 xl:grid-cols-4',
};
