import { Store } from 'lucide-react';
import { Spinner } from '@heroui/react';

export function LoadingScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center" role="status" aria-label="Loading">
      <div className="rounded-full border border-white/65 bg-white/80 p-5 shadow-[0_24px_60px_rgba(55,39,18,0.14)]">
        <Store size={32} className="text-foreground/85" />
      </div>
      <div className="space-y-2">
        <p className="display-face text-3xl font-semibold tracking-[-0.04em] text-foreground">Commerce Command Studio</p>
        <p className="text-sm uppercase tracking-[0.28em] text-foreground/48">Preparing the operations desk</p>
      </div>
      <Spinner size="sm" color="accent" />
    </div>
  );
}
