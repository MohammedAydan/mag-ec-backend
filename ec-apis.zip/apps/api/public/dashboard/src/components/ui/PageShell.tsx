import type { ReactNode } from 'react';

interface PageShellProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
}

export function PageShell({ title, subtitle, actions, children }: PageShellProps) {
  return (
    <div className="space-y-6">
      <div className="overflow-hidden rounded-[2rem] border border-white/55 bg-[linear-gradient(135deg,rgba(255,255,255,0.88),rgba(246,237,222,0.82))] px-6 py-6 shadow-[0_24px_80px_rgba(58,40,18,0.12)] md:px-8 md:py-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.26em] text-foreground/44">Commerce Command Studio</p>
            <h1 className="display-face text-4xl font-semibold tracking-[-0.04em] text-foreground md:text-5xl">{title}</h1>
            {subtitle ? <p className="mt-4 max-w-2xl text-sm leading-7 text-foreground/65 md:text-[15px]">{subtitle}</p> : null}
          </div>
          {actions ? <div className="flex flex-wrap items-center gap-2 lg:justify-end">{actions}</div> : null}
        </div>
      </div>
      <div className="space-y-5">{children}</div>
    </div>
  );
}
