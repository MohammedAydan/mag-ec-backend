import type { ReactNode } from 'react';
import { Card, Chip } from '@heroui/react';

interface StatCardProps {
  label: string;
  value: string | number;
  delta?: string;
  deltaPositive?: boolean;
  icon?: ReactNode;
  accent?: 'default' | 'success' | 'warning' | 'danger' | 'info';
}

export function StatCard({ label, value, delta, deltaPositive, icon, accent = 'default' }: StatCardProps) {
  const accentClass =
    accent === 'success' ? 'from-success/16 to-success/3 text-success' :
    accent === 'warning' ? 'from-warning/18 to-warning/4 text-warning' :
    accent === 'danger' ? 'from-danger/16 to-danger/4 text-danger' :
    accent === 'info' ? 'from-secondary/16 to-secondary/4 text-secondary' :
    'from-default/10 to-default/2 text-foreground';

  return (
    <Card className="glass-card rounded-[1.7rem] border border-white/60 shadow-[0_18px_54px_rgba(47,33,16,0.1)]">
      <Card.Content className="relative overflow-hidden px-5 py-5">
        <div className={`absolute inset-x-0 top-0 h-20 bg-gradient-to-br ${accentClass} opacity-80`} aria-hidden />
        <div className="relative flex items-start justify-between gap-4">
          <div className="space-y-3">
            <span className="block text-xs font-semibold uppercase tracking-[0.18em] text-foreground/50">{label}</span>
            <span className="display-face block text-3xl font-semibold tracking-[-0.04em] text-foreground">{value}</span>
          </div>
          {icon ? (
            <div className="rounded-full border border-black/6 bg-white/75 p-3 text-foreground/75" aria-hidden>
              {icon}
            </div>
          ) : null}
        </div>
        {delta ? (
          <Chip
            variant="soft"
            color={deltaPositive ? 'success' : 'warning'}
            size="sm"
            className="relative mt-5 w-fit border border-black/5"
          >
            {deltaPositive ? '↑' : '↓'} {delta}
          </Chip>
        ) : null}
      </Card.Content>
    </Card>
  );
}
