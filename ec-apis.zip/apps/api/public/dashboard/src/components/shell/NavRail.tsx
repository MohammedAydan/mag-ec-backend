import { NavLink } from 'react-router-dom';
import {
  BarChart3,
  Bell,
  Boxes,
  ClipboardList,
  CreditCard,
  FileText,
  LayoutDashboard,
  Package,
  Settings,
  ShieldCheck,
  ShoppingCart,
  Store,
  Tag,
  Truck,
  Users,
  X,
} from 'lucide-react';
import { Button } from '@heroui/react';
import { useAuth } from '@/lib/auth';

const GROUPS = [
  {
    label: 'Operate',
    items: [
      { to: '/home', icon: LayoutDashboard, label: 'Overview' },
      { to: '/orders', icon: ShoppingCart, label: 'Orders' },
      { to: '/fulfillment', icon: Truck, label: 'Fulfillment & returns' },
    ],
  },
  {
    label: 'Sell',
    items: [
      { to: '/catalog', icon: Package, label: 'Catalog' },
      { to: '/taxonomy', icon: Tag, label: 'Taxonomy' },
      { to: '/pricing', icon: CreditCard, label: 'Pricing & promotions' },
      { to: '/inventory', icon: Boxes, label: 'Inventory' },
    ],
  },
  {
    label: 'Engage & finance',
    items: [
      { to: '/payments', icon: CreditCard, label: 'Payments' },
      { to: '/reviews', icon: ClipboardList, label: 'Reviews' },
      { to: '/notifications', icon: Bell, label: 'Notifications' },
      { to: '/reports', icon: BarChart3, label: 'Analytics & exports' },
    ],
  },
  {
    label: 'Govern',
    items: [
      { to: '/staff', icon: Users, label: 'Staff & access' },
      { to: '/content', icon: FileText, label: 'Content & audit' },
      { to: '/system', icon: ShieldCheck, label: 'System' },
    ],
  },
];

interface NavRailProps {
  expanded: boolean;
  onToggle: () => void;
}

export function NavRail({ expanded, onToggle }: NavRailProps) {
  const { user } = useAuth();

  return (
    <nav
      className={`fixed inset-y-0 left-0 z-30 flex w-[19rem] flex-col border-r border-white/45 bg-[linear-gradient(180deg,rgba(255,252,247,0.94),rgba(247,239,226,0.92))] px-4 pb-4 pt-5 shadow-[0_24px_80px_rgba(59,41,17,0.12)] transition-transform duration-300 lg:translate-x-0 ${
        expanded ? 'translate-x-0' : '-translate-x-full'
      }`}
      aria-label="Primary navigation"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="rounded-[1.5rem] border border-black/6 bg-white/75 p-3 text-foreground/85 shadow-sm">
            <Store size={22} />
          </div>
          <div>
            <span className="display-face block text-2xl font-semibold tracking-[-0.05em] text-foreground">Atelier</span>
            <span className="block text-xs uppercase tracking-[0.24em] text-foreground/45">Commerce</span>
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          className="lg:hidden"
          onPress={onToggle}
          aria-label="Close navigation"
        >
          <X size={18} />
        </Button>
      </div>

      <div className="mt-4 rounded-[1.5rem] border border-black/6 bg-white/58 px-4 py-4">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-foreground/42">Operations desk</p>
        <p className="mt-2 text-sm leading-6 text-foreground/62">Editorial control for commerce, service, finance, and platform health.</p>
      </div>

      <div className="mt-6 flex-1 space-y-5 overflow-y-auto pr-1">
        {GROUPS.map((group) => (
          <section key={group.label} aria-label={group.label} className="space-y-3">
            <p className="px-2 text-[0.7rem] font-semibold uppercase tracking-[0.26em] text-foreground/42">{group.label}</p>
            <ul role="list" className="space-y-1.5">
              {group.items.map(({ to, icon: Icon, label }) => (
                <li key={to}>
                  <NavLink
                    to={to}
                    className={({ isActive }) =>
                      `flex items-center gap-3 rounded-[1.2rem] px-3 py-3 text-sm font-medium transition ${
                        isActive
                          ? 'bg-foreground text-background shadow-[0_14px_28px_rgba(28,20,10,0.18)]'
                          : 'text-foreground/74 hover:bg-white/72'
                      }`
                    }
                    title={label}
                  >
                    <Icon size={18} aria-hidden />
                    <span>{label}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>

      <div className="border-t border-black/6 pt-4">
        <NavLink
          to="/system"
          className={({ isActive }) =>
            `mb-3 flex items-center gap-3 rounded-[1.2rem] px-3 py-3 text-sm font-medium transition ${
              isActive ? 'bg-foreground text-background' : 'text-foreground/74 hover:bg-white/72'
            }`
          }
        >
          <Settings size={18} aria-hidden />
          <span>Settings</span>
        </NavLink>
        {user ? (
          <div className="flex items-center gap-3 rounded-[1.3rem] border border-black/6 bg-white/68 px-3 py-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-foreground text-sm font-bold text-background" aria-hidden>
              {(user.displayName ?? user.email)[0].toUpperCase()}
            </div>
            <div className="min-w-0">
              <span className="block truncate text-sm font-semibold text-foreground">{user.displayName ?? user.email}</span>
              <span className="block text-xs uppercase tracking-[0.18em] text-foreground/46">Administrator</span>
            </div>
          </div>
        ) : null}
      </div>
    </nav>
  );
}
