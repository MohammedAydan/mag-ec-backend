import { LogOut, Menu, MoonStar, RefreshCw, SunMedium } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Button, Chip } from '@heroui/react';
import { useAuth } from '@/lib/auth';

const THEME_KEY = 'atelier.admin.theme';

export function TopBar({ onMenuClick }: { onMenuClick: () => void }) {
  const { user, logout } = useAuth();
  const queryClient = useQueryClient();
  const [theme, setTheme] = useState(() => localStorage.getItem(THEME_KEY) || 'atelier-light');

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.classList.toggle('dark', theme === 'atelier-night');
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  return (
    <header className="sticky top-0 z-10 border-b border-white/40 bg-[color:color-mix(in_oklab,var(--background)_72%,transparent)] backdrop-blur-xl" role="banner">
      <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-4 px-4 py-4 md:px-6 lg:px-8">
        <div className="flex min-w-0 items-center gap-3">
          <Button variant="secondary" size="sm" className="lg:hidden" onPress={onMenuClick} aria-label="Toggle navigation">
            <Menu size={20} />
          </Button>
          <div className="min-w-0">
            <strong className="block truncate text-sm font-semibold uppercase tracking-[0.22em] text-foreground/42">Operations board</strong>
            <span className="block truncate text-sm text-foreground/72">Live command view for store performance and execution</span>
          </div>
        </div>

        <div className="hidden items-center gap-3 md:flex">
          <Button
            variant="secondary"
            onPress={() => void queryClient.invalidateQueries()}
          >
            <RefreshCw size={16} />
            <span>Refresh data</span>
          </Button>
          <Chip variant="soft" color="warning" className="border border-black/5 uppercase tracking-[0.18em]">
            Admin only
          </Chip>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onPress={() => setTheme((current) => current === 'atelier-light' ? 'atelier-night' : 'atelier-light')}
            aria-label="Switch theme"
          >
            {theme === 'atelier-light' ? <MoonStar size={17} /> : <SunMedium size={17} />}
          </Button>
          <div className="hidden items-center gap-3 rounded-full border border-white/50 bg-white/65 px-2 py-2 shadow-sm md:flex">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-foreground text-sm font-bold text-background" aria-hidden>
              {user ? (user.displayName ?? user.email)[0].toUpperCase() : '?'}
            </div>
            <div className="min-w-0">
              <span className="block max-w-52 truncate text-sm font-semibold text-foreground">{user?.displayName ?? user?.email ?? 'Admin'}</span>
              <span className="block text-xs uppercase tracking-[0.18em] text-foreground/45">Administrator</span>
            </div>
          </div>
          <Button variant="danger-soft" size="sm" onPress={() => void logout()} aria-label="Sign out">
            <LogOut size={16} />
          </Button>
        </div>
      </div>
    </header>
  );
}
