import { Outlet } from 'react-router-dom';
import { useState } from 'react';
import { NavRail } from './NavRail';
import { TopBar } from './TopBar';

export function ShellLayout() {
  const [navExpanded, setNavExpanded] = useState(false);

  return (
    <div className="dashboard-shell relative">
      <NavRail expanded={navExpanded} onToggle={() => setNavExpanded((value) => !value)} />
      {navExpanded ? (
        <div
          className="fixed inset-0 z-20 bg-black/24 backdrop-blur-sm lg:hidden"
          onClick={() => setNavExpanded(false)}
          aria-hidden
        />
      ) : null}
      <div className="lg:pl-[20rem]">
        <TopBar onMenuClick={() => setNavExpanded((value) => !value)} />
        <main className="mx-auto max-w-[1600px] px-4 pb-8 pt-6 md:px-6 lg:px-8" id="main-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
