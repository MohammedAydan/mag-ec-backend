export interface ApiError {
  message: string;
  code: string;
  statusCode: number;
  details?: unknown;
  fieldErrors?: Record<string, string[]>;
}

export class ApiRequestError extends Error {
  statusCode: number;
  code: string;
  details?: unknown;
  fieldErrors?: Record<string, string[]>;

  constructor(error: ApiError) {
    super(error.message);
    this.name = 'ApiRequestError';
    this.statusCode = error.statusCode;
    this.code = error.code;
    this.details = error.details;
    this.fieldErrors = error.fieldErrors;
  }
}

const apiBaseUrl = import.meta.env.VITE_API_BASE_URL?.replace(/\/+$/, '') ?? '/api/v1';

type JsonLikeRecord = Record<string, unknown>;

function buildUrl(path: string): string {
  return path.startsWith('http://') || path.startsWith('https://')
    ? path
    : `${apiBaseUrl}${path}`;
}

function shouldSetJsonContentType(body: RequestInit['body']): boolean {
  return Boolean(body) && !(body instanceof FormData) && !(body instanceof URLSearchParams);
}

async function parseResponse<T>(response: Response): Promise<T> {
  if (response.status === 204) return undefined as T;

  const raw = await response.text();
  let body: unknown;

  try {
    body = raw ? JSON.parse(raw) : null;
  } catch {
    body = raw;
  }

  if (!response.ok) {
    const value = (body ?? null) as JsonLikeRecord | null;
    const nested = value?.error as JsonLikeRecord | undefined;
    throw new ApiRequestError({
      message:
        (typeof value?.message === 'string' && value.message) ||
        (typeof nested?.message === 'string' && nested.message) ||
        `${response.status} ${response.statusText}`,
      code:
        (typeof value?.code === 'string' && value.code) ||
        (typeof nested?.code === 'string' && nested.code) ||
        'REQUEST_FAILED',
      statusCode: response.status,
      details: value?.details ?? nested?.details,
      fieldErrors:
        (value?.errors as Record<string, string[]> | undefined) ??
        (nested?.errors as Record<string, string[]> | undefined),
    });
  }

  return body as T;
}

function buildHeaders(init: RequestInit, accessToken?: string): HeadersInit {
  return {
    Accept: 'application/json',
    ...(shouldSetJsonContentType(init.body) ? { 'Content-Type': 'application/json' } : {}),
    ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
    ...init.headers,
  };
}

export async function publicRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(buildUrl(path), {
    ...init,
    headers: buildHeaders(init),
  });
  return parseResponse<T>(response);
}

export async function tokenRequest<T>(
  path: string,
  accessToken: string,
  init: RequestInit = {},
): Promise<T> {
  const response = await fetch(buildUrl(path), {
    ...init,
    headers: buildHeaders(init, accessToken),
  });
  return parseResponse<T>(response);
}
